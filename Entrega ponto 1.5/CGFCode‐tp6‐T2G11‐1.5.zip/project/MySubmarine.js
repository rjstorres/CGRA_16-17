/**
 * MySubmarine
 * @constructor
 */
function MySubmarine(scene) {
    CGFobject.call(this, scene);
    this.triangle = new MyTriangle(scene);
    this.angle = Math.PI;
    this.xPosition = 8.0;
    this.zPosition = 7.5;
    this.acceleration = 0;
    /*this.xVelocity = 0;
    this.zVelocity = 0;*/
};

MySubmarine.prototype = Object.create(CGFobject.prototype);
MySubmarine.prototype.constructor = MySubmarine;

MySubmarine.prototype.display = function() {
    //Display Triangle
    this.scene.pushMatrix();
    this.scene.translate(this.xPosition,0,this.zPosition);
    this.scene.rotate(this.angle,0,1,0);
    this.scene.rotate(-this.acceleration/32,1,0,0);
    this.triangle.display();
    this.scene.popMatrix();
};
