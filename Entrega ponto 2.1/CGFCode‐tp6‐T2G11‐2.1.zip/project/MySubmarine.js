/**
 * MySubmarine
 * @constructor
 */
function MySubmarine(scene) {
    CGFobject.call(this, scene);
    this.triangle = new MyTriangle(scene);
    this.angle = Math.PI;
    this.xPos = 8;
    this.zPos = 7.5;
    this.acceleration = 0;
    this.xVlc = 0;
    this.zVlc = 0;
};

MySubmarine.prototype = Object.create(CGFobject.prototype);
MySubmarine.prototype.constructor = MySubmarine;

MySubmarine.prototype.display = function() {
    //Display Triangle
    this.scene.pushMatrix();
    this.scene.translate(this.xPos,0,this.zPos);
    this.scene.rotate(this.angle,0,1,0);
    this.scene.rotate(0,1,0,0);
    this.triangle.display();
    this.scene.popMatrix();
};

//deltaAngle is in degrees
MySubmarine.prototype.setAngle = function(Angle){
    this.angle += Angle * Math.PI / 180.0;
}

MySubmarine.prototype.setAcceleration = function(Acceleration){
    this.acceleration = Acceleration;
}

MySubmarine.prototype.updatePosition = function(TimePassed){
    this.timePassed = TimePassed / 1000;
    this.maxVlc = 5;
	
    //Calculate Acceleration
    this.totalResist = -0.6;
    this.xResist = this.totalResist * this.xVlc * this.xVlc;
    this.zResist = this.totalResist * this.zVlc * this.zVlc;

    if (this.xVlc < 0){
           this.xResist *= -1;
    }
    if (this.zVlc < 0){
        this.zResist *= -1;
    }
    
    this.xAcceleration = this.acceleration * Math.cos(this.angle - Math.PI / 2.0) +this.xResist;
    this.zAcceleration = this.acceleration* Math.sin(this.angle + Math.PI/2.0) + this.zResist;

    //Calculate Velocity
    this.xVlc = this.xVlc + this.xAcceleration * this.timePassed;
    this.zVlc = this.zVlc + this.zAcceleration * this.timePassed;
    if (this.xVlc < 0.05 && this.xVlc > -0.05){
        this.xVlc = 0;
    }
    if (this.zVlc < 0.05 && this.zVlc > -0.05){
        this.zVlc = 0;
    }
    //Limit Velocity
    if (this.xVlc > this.maxVlc){
        xVlc = this.maxVlc;
    }
    else if (this.xVlc < -this.maxVlc){
        xVlc = -this.maxVlc;
    }
    if (this.zVlc > this.maxVlc){
        zVlc = this.maxVlc;
    }else if (this.zVlc < -this.maxVlc){
        zVlc = -this.maxVlc;
    }

    //Set position
    this.xPos = this.xPos + this.xVlc * this.timePassed + 
    0.5 * this.xAcceleration * this.timePassed*this.timePassed;
    this.zPos = this.zPos + this.zVlc * this.timePassed +
    0.5 * this.zAcceleration * this.timePassed* this.timePassed;

    
    this.acceleration = this.acceleration/2;
  
    
}